import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ViewCartServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>Your Cart</h2>");
        
        Cookie[] cookies = request.getCookies();
        boolean cartFound = false;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("cart")) {
                    String[] items = cookie.getValue().split(",");
                    for (String item : items) {
                        String[] parts = item.split(":");
                        out.println("<p>" + parts[0] + " - $" + parts[1] + "</p>");
                    }
                    cartFound = true;
                    break;
                }
            }
        }
        
        if (!cartFound) {
            out.println("<p>Your cart is empty.</p>");
        }
        
        out.println("<br><a href='index.html'> <button type=\"button\">Back to Shopping</button></a>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}